from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, FormView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth import login
from .models import Event, RSVP, Organizer
from .forms import EventForm, RSVPForm, UserSignupForm, OrganizerSignupForm, UserLoginForm, OrganizerLoginForm
from django.views.generic import TemplateView
from django.contrib.auth.forms import AuthenticationForm
from django.db.models import OuterRef, Subquery
from django.shortcuts import redirect  # Import the redirect function here
 
class HomePageView(TemplateView):
    template_name = 'portal/home.html'
 
 
class OrganizerEventListView(LoginRequiredMixin, ListView):
    model = Event
    template_name = 'portal/organizer_event_list.html'
    context_object_name = 'events'
 
    def get_queryset(self):
        try:
            organizer = Organizer.objects.filter(user=self.request.user).first()
            return Event.objects.filter(organizer=organizer)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
class UserEventListView(LoginRequiredMixin, ListView):
    model = Event
    template_name = 'portal/user_event_list.html'
    context_object_name = 'events'
 
    def get_queryset(self):
        try:
            user = self.request.user
            return Event.objects.annotate(
                user_rsvp_status=Subquery(
                    RSVP.objects.filter(event=OuterRef('pk'), user=user).values('status')[:1]
                )
            )
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
class EventDetailView(DetailView):
    model = Event
    template_name = 'portal/event_detail.html'
    context_object_name = 'event'
 
 
class EventCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Event
    form_class = EventForm
    template_name = 'portal/event_form.html'
    success_url = reverse_lazy('organizer-event-list')
 
    def form_valid(self, form):
        try:
            organizer = Organizer.objects.filter(user=self.request.user).first()
            form.instance.organizer = organizer
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
    def test_func(self):
        try:
            return Organizer.objects.filter(user=self.request.user).exists()
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return False
 
 
class RSVPCreateView(LoginRequiredMixin, CreateView):
    model = RSVP
    form_class = RSVPForm
    template_name = 'portal/rsvp_form.html'
    success_url = reverse_lazy('user-event-list')
 
    def form_valid(self, form):
        try:
            event = Event.objects.get(pk=self.kwargs['pk'])
            if event.is_full():
                return self.render_to_response(self.get_context_data(form=form, error="This event is already full."))
            if form.cleaned_data['status'] == 'yes':
                conflicting_events = RSVP.objects.filter(
                    user=self.request.user,
                    status='yes'
                ).exclude(event=event).filter(
                    event__date__date=event.date.date(),
                    event__date__hour=event.date.hour
                )
 
                if conflicting_events.exists():
                    conflict_event_names = ", ".join([conflict.event.name for conflict in conflicting_events])
                    return self.render_to_response(self.get_context_data(form=form, error=f"You have already RSVP'd 'Yes' to the following events at the same time: {conflict_event_names}."))
               
            form.instance.user = self.request.user
            form.instance.event = event
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
 
class UserDashboardView(LoginRequiredMixin, ListView):
    model = RSVP
    template_name = 'portal/user_dashboard.html'
    context_object_name = 'rsvps'
 
    def get_queryset(self):
        try:
            return RSVP.objects.filter(user=self.request.user)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
class UserSignupView(CreateView):
    form_class = UserSignupForm
    template_name = 'portal/user_signup.html'
    success_url = reverse_lazy('user-login')
 
    def form_valid(self, form):
        try:
            user = form.save()
            login(self.request, user)
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
 
class OrganizerSignupView(CreateView):
    form_class = OrganizerSignupForm
    template_name = 'portal/organizer_signup.html'
    success_url = reverse_lazy('organizer-login')
 
    def form_valid(self, form):
        try:
            user = form.save()
            Organizer.objects.create(user=user, name=form.cleaned_data['name'])
            login(self.request, user)
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
 
class UserLoginView(FormView):
    form_class = UserLoginForm
    template_name = 'portal/user_login.html'
    success_url = reverse_lazy('user-event-list')
 
    def form_valid(self, form):
        try:
            user = form.get_user()
            login(self.request, user)
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
 
class OrganizerLoginView(FormView):
    form_class = OrganizerLoginForm
    template_name = 'portal/organizer_login.html'
    success_url = reverse_lazy('organizer-event-list')
 
    def form_valid(self, form):
        try:
            user = form.get_user()
            print("User:", user)
            organizers = Organizer.objects.filter(user=user)
            print("Organizers:", organizers)
            if organizers.exists():
                login(self.request, user)
                return super().form_valid(form)
            else:
                form.add_error(None, 'You are not authorized as an organizer.')
                return self.form_invalid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
 
class EventUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Event
    form_class = EventForm
    template_name = 'portal/event_form.html'
    success_url = reverse_lazy('organizer-event-list')
 
    def form_valid(self, form):
        try:
            form.instance.organizer = Organizer.objects.filter(user=self.request.user).first()
            return super().form_valid(form)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return self.form_invalid(form)
 
    def test_func(self):
        try:
            event = self.get_object()
            return event.organizer.user == self.request.user
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return False
 
 
class EventDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Event
    template_name = 'portal/event_confirm_delete.html'
    success_url = reverse_lazy('organizer-event-list')
 
    def test_func(self):
        try:
            event = self.get_object()
            return event.organizer.user == self.request.user
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return False
 
 
class UserAttendingEventsView(LoginRequiredMixin, ListView):
    model = RSVP
    template_name = 'portal/user_attending_events.html'
    context_object_name = 'rsvps'
 
    def get_queryset(self):
        try:
            return RSVP.objects.filter(user=self.request.user, status='yes')
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
class UserNotAttendingEventsView(LoginRequiredMixin, ListView):
    model = RSVP
    template_name = 'portal/user_not_attending_events.html'
    context_object_name = 'rsvps'
 
    def get_queryset(self):
        try:
            return RSVP.objects.filter(user=self.request.user, status='no')
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
class RSVPUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = RSVP
    form_class = RSVPForm
    template_name = 'portal/rsvp_update_form.html'
 
    def form_valid(self, form):
        try:
            form.save()
            return super().form_valid(form)
        except Exception as e:
            return self.form_invalid(form)
 
    def get_success_url(self):
        try:
            rsvp = self.get_object()
            if rsvp.status == 'yes':
                return reverse_lazy('user-attending-events')
            else:
                return reverse_lazy('user-not-attending-events')
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return reverse_lazy('user-event-list')
 
    def test_func(self):
        try:
            rsvp = self.get_object()
            return rsvp.user == self.request.user
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return False
 
 
class EventAttendeesView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = Event
    template_name = 'portal/event_attendees.html'
    context_object_name = 'event'
 
    def get_context_data(self, **kwargs):
        try:
            context = super().get_context_data(**kwargs)
            context['attendees'] = RSVP.objects.filter(event=self.object, status='yes')
            return context
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return {}
 
    def test_func(self):
        try:
            event = self.get_object()
            return event.organizer.user == self.request.user
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return False
 
 
class UserFavoriteEventsView(LoginRequiredMixin, ListView):
    model = Event
    template_name = 'portal/user_favorite_events.html'
    context_object_name = 'events'
 
    def get_queryset(self):
        try:
            favorite_events = self.request.session.get('favorites', [])
            return Event.objects.filter(pk__in=favorite_events)
        except Exception as e:
            # handle exception (log it, return a default value, etc.)
            return []
 
 
def favorite_event(request, pk):
    try:
        event_id = str(pk)
        favorites = request.session.get('favorites', [])
        if event_id not in favorites:
            favorites.append(event_id)
            request.session['favorites'] = favorites
        return redirect('user-event-list')
    except Exception as e:
        # handle exception (log it, return a default value, etc.)
        return redirect('user-event-list')
 
 
def unfavorite_event(request, pk):
    try:
        event_id = str(pk)
        favorites = request.session.get('favorites', [])
        if event_id in favorites:
            favorites.remove(event_id)
            request.session['favorites'] = favorites
        return redirect('user-event-list')
    except Exception as e:
        # handle exception (log it, return a default value, etc.)
        return redirect('user-event-list')
 
