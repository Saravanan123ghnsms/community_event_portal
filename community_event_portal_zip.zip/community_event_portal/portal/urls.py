from django.conf import settings
from django.urls import path
from .views import HomePageView,UserSignupView, OrganizerSignupView, EventCreateView, EventDetailView, OrganizerEventListView, UserEventListView, EventUpdateView, EventDeleteView, RSVPCreateView, UserDashboardView, UserLoginView, OrganizerLoginView, UserAttendingEventsView, UserNotAttendingEventsView, RSVPUpdateView, EventAttendeesView, UserFavoriteEventsView, favorite_event, unfavorite_event
from django.conf.urls.static import static

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('signup/user/', UserSignupView.as_view(), name='user-signup'),
    path('signup/organizer/', OrganizerSignupView.as_view(), name='organizer-signup'),
    path('login/user/', UserLoginView.as_view(), name='user-login'),
    path('login/organizer/', OrganizerLoginView.as_view(), name='organizer-login'),
    path('events/organizer/', OrganizerEventListView.as_view(), name='organizer-event-list'),
    path('events/user/', UserEventListView.as_view(), name='user-event-list'),
    path('events/<int:pk>/', EventDetailView.as_view(), name='event-detail'),
    path('events/create/', EventCreateView.as_view(), name='event-create'),
    path('events/update/<int:pk>/', EventUpdateView.as_view(), name='event-update'),
    path('events/delete/<int:pk>/', EventDeleteView.as_view(), name='event-delete'),
    path('events/<int:pk>/rsvp/', RSVPCreateView.as_view(), name='event-rsvp'),
    path('events/<int:pk>/rsvp/update/', RSVPUpdateView.as_view(), name='rsvp-update'),
    path('dashboard/', UserDashboardView.as_view(), name='user-dashboard'),
    path('events/attending/', UserAttendingEventsView.as_view(), name='user-attending-events'),
    path('events/not-attending/', UserNotAttendingEventsView.as_view(), name='user-not-attending-events'),
    path('events/<int:pk>/attendees/', EventAttendeesView.as_view(), name='event-attendees'),
    path('events/<int:pk>/favorite/', favorite_event, name='favorite-event'),
    path('events/<int:pk>/unfavorite/', unfavorite_event, name='unfavorite-event'),
    path('events/favorites/', UserFavoriteEventsView.as_view(), name='user-favorite-events'),
]+static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
