from datetime import datetime
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import Organizer, Event, RSVP

class UserSignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

class OrganizerSignupForm(UserCreationForm):
    name = forms.CharField(max_length=100)

    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=commit)
        organizer = Organizer(user=user, name=self.cleaned_data['name'])
        if commit:
            organizer.save()
        return user

from django import forms
from .models import Event, Organizer

from django import forms
from .models import Event
from django.core.exceptions import ValidationError
from django.utils import timezone
 
MAX_FILE_SIZE = 2000 * 1024

# class EventForm(forms.ModelForm):
#     class Meta:
#         model = Event
#         fields = ['name', 'description', 'date', 'capacity', 'banner', 'category']
#         widgets = {
#             'date': forms.DateTimeInput(attrs={
#                 'type': 'datetime-local',  # This will create a date and time picker
#                 'class': 'form-control',
#                 'min': timezone.now().strftime('%Y-%m-%dT%H:%M'),# Add any additional classes for styling
#             }),
#         }
  
#     def clean_banner(self):
#             banner = self.cleaned_data.get('banner')    
       
#             if banner:
#                 if banner.size > MAX_FILE_SIZE:
#                     raise ValidationError("The file size cannot exceed 5 KB.")
       
#             return banner

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['name', 'description', 'date', 'capacity', 'banner', 'category']
        widgets = {
            'date': forms.TextInput(attrs={
                'class': 'form-control flatpickr',  # Add a class for Flatpickr
                'placeholder': 'mm/dd/yyyy HH:mm',  # Placeholder for user guidance
            }),
        }

    # def clean_date(self):
    #     date_input = self.cleaned_data.get('date')
    #     if date_input:
    #         try:
    #             # Parse the date input in the format mm/dd/yyyy HH:mm
    #             parsed_date = datetime.strptime(date_input, '%m/%d/%Y %H:%M')
    #             cleaned_date = timezone.make_aware(parsed_date)
    #             return cleaned_date
    #         except ValueError:
    #             raise ValidationError("Enter a valid date and time in the format mm/dd/yyyy HH:mm.")
    #     return date_input
    def clean_date(self):
        
        date_input = self.cleaned_data.get('date')
        if date_input:
            
        # Check if date_input is already a datetime object
            if isinstance(date_input, datetime):
                 if date_input.tzinfo is not None:
                     return date_input
                 else:
                     
                
                    return timezone.make_aware(date_input)  # Ensure it's timezone-aware

            try:
                
            # Parse the date input in the format mm/dd/yyyy HH:mm
                parsed_date = datetime.strptime(date_input, '%m/%d/%Y %H:%M')
                cleaned_date = timezone.make_aware(parsed_date)
                return cleaned_date
            
            except ValueError:
                
                raise ValidationError("Enter a valid date and time in the format mm/dd/yyyy HH:mm.")
            
        return date_input
    
    
    def clean_banner(self):
        banner = self.cleaned_data.get('banner')    
       
        if banner:
            
            if banner.size > MAX_FILE_SIZE:
                
                raise ValidationError("The file size cannot exceed 5 KB.")
       
        return banner
        
            
    
    
    
    
    
from django import forms
from .models import RSVP

class RSVPForm(forms.ModelForm):
    class Meta:
        model = RSVP
        fields = ['status']


# class UserLoginForm(AuthenticationForm):
#     pass

class UserLoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Set custom labels for the fields
        self.fields['username'].label = "Username"  # Custom label for username
        self.fields['password'].label = "Password"

class OrganizerLoginForm(AuthenticationForm):
    pass
