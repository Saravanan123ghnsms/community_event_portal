from django.db import models
from django.contrib.auth.models import User

class Organizer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Event(models.Model):
    organizer = models.ForeignKey(Organizer, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField()
    date = models.DateTimeField()
    capacity = models.PositiveIntegerField()
    banner = models.ImageField(upload_to='event_banners/', blank=True, null=True)
    category = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    def is_full(self):
        return self.rsvp_set.filter(status='yes').count() >= self.capacity

class RSVP(models.Model):
    STATUS_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    status = models.CharField(max_length=3, choices=STATUS_CHOICES, default='yes')

    def __str__(self):
        return f"{self.user} - {self.event} - {self.status}"
